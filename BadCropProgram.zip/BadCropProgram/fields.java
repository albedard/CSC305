/*
	This is what I used to test my Farm.java file. I created a farm object from the text file and ran the
	method to find any groups of bad crops. I have also included the test file, 'farm.txt', for you to edit
	and play around with to see how my code works
*/
public class fields{

	public static void main(String[] args){

		Farm field = new Farm();

		//field.displayFarm();

		System.out.println("Number of bad crops: " + field.getBadCrops());

	}
}