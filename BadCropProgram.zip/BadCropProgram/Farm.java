//Import for reading the file
import java.io.*;
import java.util.*;

/*
	I decided the best way to tackle this in Java is to create an object for the 'farm'. Each farm
	object has a function to find the number of bad crops. The only accessable functions are the function
	to find the bad crops, and the function to display the crops (I added it into the code for testing
	purposes)
*/
public class Farm{

	//A few variables globally available within this class
	private int badCrops = 0;
	//The size of the double array is taking into consideration that all the fields
	//are going to be the same size
	private char[][] cropLayout = new char[12][12];

	//The constructor calls the createFarm() method
	public Farm(){

		createFarm();
	}

	/*
		This function creates the farm matrix, which is basically an array of arrays.
		It does not need to return anything because it is just populating the cropLayout
		array with the arrays for each column
	*/
	private void createFarm(){

	  //Try/Catch for file reading
      try{

		  //Gets all the objects needed to read the file
		  FileReader fileReader = new FileReader(new File("farm.txt"));
		  int numLine = 0;
 		  BufferedReader br = new BufferedReader(fileReader);
 		  String line = null;

		  //Reads the file until it reaches the end
		  while ((line = br.readLine()) != null) {
			  for(int i = 0; i < line.length(); i ++){

				  //Reads the char in the spot in the line
				  char node = line.charAt(i);
				  //System.out.print(node);

				  //Making the arrays just of the good and bad crops
				  if(node == 'X' || node == ' '){
				  	cropLayout[numLine][i] = node;
				  }
			  }

			  //Increments the line number
			  numLine++;
		  }
	  }
	  //Catch statement for file reading
	  catch(IOException e) {
    	  System.err.println("Error: " + e.getMessage());
	  }

	}

	/*
		This function's purpose is to take the crop matrix and find out how
		many groups of bad crops are in the farm.  Considering the fact that
		Java is a copy-in language, I will call in the cropLayout array so that
		any edits I make will not ruin the original array.
	*/
	private void findBadCrops(char[][] cropLayoutCpy){

		//Loop for outside array
		for(int i = 0; i < cropLayoutCpy.length - 1; i++){

			//Loop for inner arrays
			for(int j = 0; j < cropLayoutCpy[0].length - 1; j++){

				if(cropLayoutCpy[i][j] == 'X'){

					//Find and clear the adjacent bad crops to continue the search
					//for bad crops
					badCrops += 1;

					/* A NOTE ABOUT THE FUNCTION/METHOD I AM CALLING**
						This is something I would ONLY do with Java, or another copy-in language.
						the original file and data is untouched by the method. If it were a different
						type of language I did not know very well, I would not do something like this
						because of the risk that the original data may be changed */
					cropLayoutCpy = clearAdjacent(cropLayoutCpy, i, j);

				}

			}
		}



	}

	/*
		A function that works recursively. It takes the copy thus far and clears out the crops
		to make searching easier. An entire section of bad crops will be 'wiped' from the field
		so that it will not get confused when the program is looking for bad crops.
	*/
	private char[][] clearAdjacent(char[][] cropLayoutCpy, int col, int row){


		//Goes through entire area searching for adjacent X's and will recursively call the
		//function if one is found to check all sides of that X
		if(cropLayoutCpy[col + 1][row] == 'X'){

			//The statement below is the one I used to trace my steps in this method
			//I had one of these in every if statement so that it would print out the path
			//it was taking.
			//System.out.println("Badcrops: " + badCrops + "Col/row" + (col) + " " + row);

			//'Wipes out' the bad crops
			cropLayoutCpy[col + 1][row] = ' ';
			cropLayoutCpy = clearAdjacent(cropLayoutCpy, col + 1, row);

		}
		if(cropLayoutCpy[col][row + 1] == 'X'){

			//'Wipes out' the bad crops
			cropLayoutCpy[col][row + 1] = ' ';
			cropLayoutCpy = clearAdjacent(cropLayoutCpy, col, row+1);
		}
		if(cropLayoutCpy[col][row-1] == 'X'){

			//'Wipes out' the bad crops
			cropLayoutCpy[col][row-1] = ' ';
			cropLayoutCpy = clearAdjacent(cropLayoutCpy, col, row-1);
		}

		//Finally, at the end, clears the X in the beginning
		if(cropLayoutCpy[col][row] == 'X'){
			cropLayoutCpy[col][row] = ' ';
		}

		//Returns the array as it is currently
		return cropLayoutCpy;
	}


	//Function to get the bad crops for the farm object
	public int getBadCrops(){

		//Calls the function to find the bad crops
		findBadCrops(cropLayout);

		//Returns the bad crops
		return badCrops;

	}

	//A display function for testing purposes
	public void displayFarm(){

		for(int i = 0; i < cropLayout.length-1; i++){

			//Starts printing the crops on a new line with the '|' for the ends of the field
			System.out.print("\n");
			System.out.print("|");
			displayRow(cropLayout[i]);
			System.out.print("|");
			System.out.print("\n");
		}
	}

	//A function for the display function to display the individual columns
	private void displayRow(char[]field){

		//Loops through array and prints out each character individually
		for(int j = 0; j < field.length - 1; j++){
			System.out.print(field[j]);
		}

	}


}