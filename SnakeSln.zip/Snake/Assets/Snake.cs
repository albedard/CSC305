﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine.SceneManagement;

public class Snake : MonoBehaviour {

    // 200x300 px window will apear in the center of the screen.
    private Rect windowRect = new Rect((Screen.width - 200) / 2, (Screen.height - 300) / 2, 200, 300);
    // Only show it if needed.
    private bool show = false;

    // hungry snake
    bool ate = false;

    //Gameobject public
    GameObject g;

    // Tail Prefab
    public GameObject tailPrefab;

    // Current Movement Direction defaults to the right
    Vector2 dir = Vector2.right;
    // Keep Track of Tail
    List<Transform> tail = new List<Transform>(); 

    // Use this for initialization
    void Start () {

        //Sets the time scale
        Time.timeScale = 1;

        // Move the Snake every 300ms
        InvokeRepeating("Move", 0.3f, 0.3f);

    }

	
	// Update is called once per frame
	void Update () {

        // Move in a new Direction?
        if (Input.GetKey(KeyCode.RightArrow))
            dir = Vector2.right;
        else if (Input.GetKey(KeyCode.DownArrow))
            dir = -Vector2.up;    // '-up' means 'down'
        else if (Input.GetKey(KeyCode.LeftArrow))
            dir = -Vector2.right; // '-right' means 'left'
        else if (Input.GetKey(KeyCode.UpArrow))
            dir = Vector2.up;
    }

    void Move()
    {
        // Save current position
        Vector2 v = transform.position;

        // Move head into new direction
        transform.Translate(dir);

        // If snake eats food
        if (ate)
        {
            // Load Prefab into the world
            g = (GameObject)Instantiate(tailPrefab, v,Quaternion.identity);

            // Keep track of it in tail list
            tail.Insert(0, g.transform);

            // Snake still hungry
            ate = false;
        }
        // If there is not a tail
        else if (tail.Count > 0)
        {
            // Move last tail to where the Head was
            tail.Last().position = v;

            // Add to front of list, remove from the back
            tail.Insert(0, tail.Last());
            tail.RemoveAt(tail.Count - 1);
        }

    }

    void OnGUI()
    {
        if (show)
            windowRect = GUI.Window(0, windowRect, DialogWindow, "Game Over");
    }

    // This is the actual window.
    void DialogWindow(int windowID)
    {
        float y = 20;
        GUI.Label(new Rect(5, y, windowRect.width, 20), "You lose!");

        if (GUI.Button(new Rect(5, y+23, windowRect.width - 10, 20), "Restart"))
        {
            //Application.LoadLevel(0);
            SceneManager.LoadScene(0);
            show = false;
        }

        if (GUI.Button(new Rect(5, y+47, windowRect.width - 10, 20), "Exit"))
        {

            Application.Quit();
            show = false;
        }
    }

    // To open the dialogue from outside of the script.
    public void Open()
    {
        show = true;
    }

    void OnTriggerEnter2D(Collider2D coll)
    {
        // Food?
        if (coll.name.StartsWith("GoodfoodPrefab"))
        {
            // Get longer in next Move call
            ate = true;

            //Speeds up the game when eaten (can't find a good speed)
            Time.timeScale = Time.timeScale + 0.025f;

            // Remove the Food
            Destroy(coll.gameObject);
        }

        else if (coll.name.StartsWith("Badfood"))
        {

            //STILL NEEDS WORK (maybe not)
            //For some reason this leaves the tail piece behind and doesn't delete it
            //EDIT: I decided to keep it as an 'added feature' to the game
            //if the user collides with it, they lose :)

            //Removes the last tail element as an obstacle
            tail.Remove(tail[tail.Count - 1]);

            
            //Remove the food
            Destroy(coll.gameObject);
        }

        // Collided with Tail or Border ends the game
        else
        {
            Time.timeScale = 0;

            Open();
        }
    }

}
