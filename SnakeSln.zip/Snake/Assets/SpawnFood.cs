﻿using UnityEngine;
using System.Collections;

public class SpawnFood : MonoBehaviour {
    // Prefab for the good food
    public GameObject goodFoodPrefab, badFoodPrefab;

    //Keeps track of the number of frames
    public int frameNum = 0;

    // Borders
    public Transform border_top;
    public Transform border_bottom;
    public Transform border_left;
    public Transform border_right;

    // Use this for initialization
    void Start () {

        // Spawn food every 4 seconds, starting in 3
        //InvokeRepeating("Spawn", 3, 4);
        Spawn(goodFoodPrefab);
        Spawn(badFoodPrefab);
    }

    // Update is called once per frame
    void Update()
    {
        //Increments the frame counter
        frameNum += 1;
        
        //The conditions if the food has been eaten
        //Checks to see if the object is on the map
        //If it is not, spawns the object randomly
        if(GameObject.Find("GoodfoodPrefab(Clone)") == null)
        {
            Spawn(goodFoodPrefab);
        }

        if (GameObject.Find("Badfood(Clone)") == null)
        {
            Spawn(badFoodPrefab);
        }

        if(frameNum == 250)
        {
            //Resets the frame number to zero
            frameNum = 0;

            //Destroys the food object and respawns it in a different location
            DestroyObject(GameObject.Find("Badfood(Clone)"));
            Spawn(badFoodPrefab);
        }
    }

    //the spawn function
    //Later see if you can make the food type a parameter and have it randomize
    void Spawn(GameObject food)
    {
        // x position between left & right border
        int x = (int)Random.Range(border_left.position.x,
                                  border_right.position.x);

        // y position between top & bottom border
        int y = (int)Random.Range(border_bottom.position.y,
                                  border_top.position.y);

        // Instantiate the specified food at (x, y)
        Instantiate(food,new Vector2(x, y),Quaternion.identity); // default rotation
    }

}
